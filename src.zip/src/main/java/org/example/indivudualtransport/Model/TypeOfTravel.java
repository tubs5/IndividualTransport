package org.example.indivudualtransport.Model;

public enum TypeOfTravel {
    Car,Bike,Foot
}
