package org.example.indivudualtransport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndivudualTransportApplication {

    public static void main(String[] args) {
        SpringApplication.run(IndivudualTransportApplication.class, args);
    }

}
