package org.example.indivudualtransport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndivudualTransportApplicationTests {

    @Test
    void contextLoads() {
    }

}
